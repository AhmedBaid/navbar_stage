# Dashboard Gestion de Stock :

1. install dependencies `npm install`
2. start the development server `npm run dev`
3. tailwind-css , visit <a>https://tailwindcss.com/docs/guides/vite</a>
