import React from 'react'

const LogOut = () => {
    return (
        <div>SignOut</div>
    )
}

export default LogOut