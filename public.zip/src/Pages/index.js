// pages/index.js
export { default as Acceuil } from './Acceuil';
export { default as Commandes } from './Commandes';
export { default as Stocks } from './Stocks';
export { default as Fournisseurs } from './Fournisseurs';
export { default as Client } from './Client';
export { default as Historiques } from './Historiques';
export { default as LogOut } from './LogOut';
export { default as User } from './User';
