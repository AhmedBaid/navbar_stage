import React from 'react'

const Commandes = () => {
    return (
        <div>Commandes</div>
    )
}

export default Commandes