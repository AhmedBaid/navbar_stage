import React from 'react'

const Historiques = () => {
    return (
        <div>Historiques</div>
    )
}

export default Historiques