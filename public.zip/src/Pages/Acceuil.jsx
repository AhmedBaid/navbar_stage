import React from 'react'

const Acceuil = () => {
    return (
        <div>Acceuil</div>
    )
}

export default Acceuil