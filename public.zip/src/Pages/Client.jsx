import React from 'react'

const Client = () => {
    return (
        <div>Direction & Bureaus</div>
    )
}

export default Client