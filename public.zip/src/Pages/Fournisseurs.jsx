import React from 'react'

const Fournisseurs = () => {
    return (
        <div>Fournisseurs</div>
    )
}

export default Fournisseurs